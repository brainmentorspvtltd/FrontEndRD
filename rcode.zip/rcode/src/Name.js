// In React A Component is just a Function.
// And this function returns JSX.
// JSX - JavaScript and XML. Close to HTML, 
//But internally all the JSX thing
// are just Objects

import { useState } from "react";

// IN React We don't have HTML we Have JSX
export const Name=()=>{
    //const [firstName, setFirstName] = useState('');
    //const [lastName, setLastName] = useState('');
    const [fullName, setFullName] = useState('');
    var firstName = "";
    var lastName = "";
    const showName = ()=>{
        setFullName(firstName +" "+ lastName);
        console.log("I am the Show Name");
    }
    const takeFirstName = (event)=>{
        //setFirstName(event.target.value);
        firstName = event.target.value;
        //console.log("Take First Name Call.. ",firstName);
    }
    const takeLastName = (event)=>{
        //setLastName(event.target.value);
        lastName = event.target.value;
        //console.log("Take Last Name Call.. ",lastName);
    }
    return (
        <div>
    <div>
    <label>First Name : </label>
    <input onChange={takeFirstName} type='text' placeholder='Type Name Here'/>
    </div>
    <div>
    <label>Last Name : </label>
    <input onChange={takeLastName} type='text' placeholder='Type Name Here'/>
    </div>
    <div>
        <button onClick={showName}>Show Name</button>
        &nbsp;
        <button>Clear All</button>
    </div>
    <h1>Your Name is {fullName}</h1>
    </div>
    );
}
// function scope inside this JS
//  export 
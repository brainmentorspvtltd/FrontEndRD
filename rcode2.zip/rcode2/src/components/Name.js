import { useState } from "react";
import { NameButton } from "../widgets/Button"
import { TextBox } from "../widgets/TextBox"
import { Title } from "../widgets/Title"

export const Name = ()=>{
    var firstName = "";
    var lastName = "";
    const [fullName, setFullName] =useState('');
    const takeFirstName = (event)=>{
        firstName = event.target.value;
        //console.log('First  Name ',event.target.value);
    }
    const takeLastName = (event)=>{
        lastName = event.target.value;
        //console.log('Last  Name ',event.target.value);
    }
    const showName = ()=>{
        setFullName(firstName+" "+lastName);
    }
    const clearAll = ()=>{

    }
    return (
        <>
        <TextBox fn = {takeFirstName} label="First Name" />
        <TextBox fn={takeLastName} label="Last Name"/>
        <NameButton fn={showName} label="Show Name" color="success"/>
        <NameButton fn={clearAll} label="Clear All" color="error"/>
        <Title result = {fullName}/>
        </>

    )
}
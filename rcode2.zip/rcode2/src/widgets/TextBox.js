import TextField from '@mui/material/TextField';
export const TextBox = (obj)=>{
    
    const placeHolder = `Type ${obj.label} Here`;
    console.log('Place Holder ', placeHolder);
    return (
    <div>
    <TextField onChange={obj.fn}  placeholder={placeHolder} id="outlined-basic" label={obj.label} variant="outlined" />
    </div> );   
}
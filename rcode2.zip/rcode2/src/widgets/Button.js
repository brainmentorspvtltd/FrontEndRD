import Button from '@mui/material/Button';
export const NameButton = (props)=>{
    return (<Button onClick={props.fn}   color={props.color} variant="contained">{props.label}</Button>);
}
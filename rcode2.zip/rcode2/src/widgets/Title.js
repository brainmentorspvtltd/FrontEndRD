export const Title = (props)=>{
    return (<h2>{props.result}</h2>);
}
// In React A Component is just a Function.
// And this function returns JSX.
// JSX - JavaScript and XML. Close to HTML, 
//But internally all the JSX thing
// are just Objects
import Button from '@mui/material/Button';
import { useState } from "react";
import TextField from '@mui/material/TextField';

// IN React We don't have HTML we Have JSX
export const Name=()=>{
    //const [firstName, setFirstName] = useState('');
    //const [lastName, setLastName] = useState('');
    const [fullName, setFullName] = useState('');
    var firstName = "";
    var lastName = "";
    const initCap = (str)=>{
        return str.charAt(0).toUpperCase() + str.substring(1).toLowerCase();
    }
    const properCase = ()=>{
        return initCap(firstName) + " "+ initCap(lastName);
    }

    const showName = ()=>{
        setFullName(properCase());
        console.log("I am the Show Name");
    }
    const takeFirstName = (event)=>{
        //setFirstName(event.target.value);
        firstName = event.target.value;
        //console.log("Take First Name Call.. ",firstName);
    }
    const takeLastName = (event)=>{
        //setLastName(event.target.value);
        lastName = event.target.value;
        //console.log("Take Last Name Call.. ",lastName);
    }
    return (
        <div>
    <div>
    <label>First Name : </label>
    <TextField onChange={takeFirstName} placeholder='Type Name Here' id="outlined-basic" label="First Name" variant="outlined" />
    {/* <input onChange={takeFirstName} type='text' placeholder='Type Name Here'/> */}
    </div>
    <div>
    <label>Last Name : </label>
    <TextField onChange={takeLastName}  placeholder='Type Name Here' id="outlined-basic" label="Last Name" variant="outlined" />
    {/* <input onChange={takeLastName} type='text' placeholder='Type Name Here'/> */}
    </div>
    <div>
    <Button  onClick={showName} color="success" variant="contained">Show Name</Button>
    &nbsp;
    <Button color="error" variant="contained">Clear All</Button>
        {/* <button onClick={showName}>Show Name</button>
        &nbsp;
        <button>Clear All</button> */}
    </div>
    <h1>Your Name is {fullName}</h1>
    </div>
    );
}
// function scope inside this JS
//  export 
import React from "react";
import { Name } from "./components/Name";


function App(){
  return (<Name/>);
}
export default App;
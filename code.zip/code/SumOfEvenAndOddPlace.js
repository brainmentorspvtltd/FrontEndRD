function sum(num, arr){
    if(num == 0){
        return 0;
    }
    var place = 1 + sum(parseInt(num/10), arr); // Small Problem + Cycle
    var rem = num % 10;
    if(place % 2 !=0){
        // Odd Sum
        if(arr.length==0){
            arr.push(rem);
        }
        else{
            
            arr[0] = arr[0] + rem;
        }
    }
    else{
        // Even Sum
        if(arr.length ==1){
        arr.push(rem);
    }
        else{
            arr[1] = arr[1] + rem; 
        }
}
    return place;
}
